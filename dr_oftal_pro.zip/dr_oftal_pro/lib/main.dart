
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

void main() => runApp(
      ChangeNotifierProvider(
        create: (_) => AppState(),
        child: const DrOftalPro(),
      ),
    );

class AppState extends ChangeNotifier {
  bool isDarkMode = false;
  String mode = 'snellen'; // 'snellen' ou 'tumblingE'

  void toggleTheme() {
    isDarkMode = !isDarkMode;
    notifyListeners();
  }

  void setMode(String newMode) {
    mode = newMode;
    notifyListeners();
  }
}

class DrOftalPro extends StatelessWidget {
  const DrOftalPro({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);

    return MaterialApp(
      debugShowCheckedModeBanner: false,
      theme: appState.isDarkMode ? ThemeData.dark() : ThemeData.light(),
      home: const HomeScreen(),
    );
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final appState = Provider.of<AppState>(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Dr. Oftal Pro')),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Image.asset('assets/logo.png', height: 120),
          const SizedBox(height: 30),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const ModeSelector()),
            ),
            child: const Text("Iniciar Teste"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.push(
              context,
              MaterialPageRoute(builder: (_) => const SettingsScreen()),
            ),
            child: const Text("Configurações"),
          ),
        ],
      ),
    );
  }
}
